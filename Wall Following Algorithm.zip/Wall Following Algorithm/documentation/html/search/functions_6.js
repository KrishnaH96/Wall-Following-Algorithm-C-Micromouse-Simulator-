var searchData=
[
  ['run_95',['run',['../classrwa2group12_1_1_algorithm.html#a1b371b8b353aace9f9d1375e7e637f0c',1,'rwa2group12::Algorithm']]]
];
