var classrwa2group12_1_1_robot =
[
    [ "get_direction", "classrwa2group12_1_1_robot.html#a1e723d97438fd29df4766c291a2efe2a", null ],
    [ "get_directionnew", "classrwa2group12_1_1_robot.html#a82393777bc4303b6c30f66e1413a6b8b", null ],
    [ "get_m_final_backtrace", "classrwa2group12_1_1_robot.html#a8f8e89723fe1cc34657889d4252dfb17", null ],
    [ "get_m_position_backtrace", "classrwa2group12_1_1_robot.html#abad408926b82e8b2a75252f6b26a3787", null ],
    [ "get_position", "classrwa2group12_1_1_robot.html#a5be4a2c845adc7c78ca5633e0740f57e", null ],
    [ "get_position_logx", "classrwa2group12_1_1_robot.html#af8332eedd2920d24dfdc7373f2c25b74", null ],
    [ "get_position_logy", "classrwa2group12_1_1_robot.html#ae245d3fd93b3ab1128ab4fe6615adda7", null ],
    [ "move_forward", "classrwa2group12_1_1_robot.html#a0978752b5a11c3fbc89ab81adff23ff0", null ],
    [ "set_direction", "classrwa2group12_1_1_robot.html#a22e4d6ac122d873d3359f14ea8e38332", null ],
    [ "set_directionnew", "classrwa2group12_1_1_robot.html#a26a5a4963b4eb7054f7348748605adf9", null ],
    [ "set_m_final_backtrace", "classrwa2group12_1_1_robot.html#a04fe16b7e44b3631e7cfe3fbe997071f", null ],
    [ "set_m_position_backtrace", "classrwa2group12_1_1_robot.html#a70bb9e26d668499fc58bc87bb9f6831c", null ],
    [ "set_position", "classrwa2group12_1_1_robot.html#ac35dd113537e7d4c0ba37909985a4fcb", null ],
    [ "set_position_logx", "classrwa2group12_1_1_robot.html#a5b752bc6e4e6702c2ae3ca4995733e44", null ],
    [ "set_position_logy", "classrwa2group12_1_1_robot.html#ab08e2f28f0435390597d1840172fa3bd", null ],
    [ "turn_left", "classrwa2group12_1_1_robot.html#ab7bb45954e05857353b4410cf374b319", null ],
    [ "turn_right", "classrwa2group12_1_1_robot.html#a635fb9fcbc1cc127b3521a1fd6d83af6", null ]
];