var searchData=
[
  ['generate_5fgoal_11',['generate_goal',['../classrwa2group12_1_1_algorithm.html#aa4b3d03fe8bfc63ce10a9ca120e17c97',1,'rwa2group12::Algorithm']]],
  ['get_5fdirection_12',['get_direction',['../classrwa2group12_1_1_robot.html#a1e723d97438fd29df4766c291a2efe2a',1,'rwa2group12::Robot']]],
  ['get_5fdirectionnew_13',['get_directionnew',['../classrwa2group12_1_1_robot.html#a82393777bc4303b6c30f66e1413a6b8b',1,'rwa2group12::Robot']]],
  ['get_5fm_5ffinal_5fbacktrace_14',['get_m_final_backtrace',['../classrwa2group12_1_1_robot.html#a8f8e89723fe1cc34657889d4252dfb17',1,'rwa2group12::Robot']]],
  ['get_5fm_5ffinal_5fdir_5falgorithm_15',['get_m_final_dir_algorithm',['../classrwa2group12_1_1_algorithm.html#ad30e3e3f71611688581a271f1b9d1db5',1,'rwa2group12::Algorithm']]],
  ['get_5fm_5fposition_5fbacktrace_16',['get_m_position_backtrace',['../classrwa2group12_1_1_robot.html#abad408926b82e8b2a75252f6b26a3787',1,'rwa2group12::Robot']]],
  ['get_5fposition_17',['get_position',['../classrwa2group12_1_1_robot.html#a5be4a2c845adc7c78ca5633e0740f57e',1,'rwa2group12::Robot']]],
  ['get_5fposition_5flogx_18',['get_position_logx',['../classrwa2group12_1_1_robot.html#af8332eedd2920d24dfdc7373f2c25b74',1,'rwa2group12::Robot']]],
  ['get_5fposition_5flogy_19',['get_position_logy',['../classrwa2group12_1_1_robot.html#ae245d3fd93b3ab1128ab4fe6615adda7',1,'rwa2group12::Robot']]]
];
