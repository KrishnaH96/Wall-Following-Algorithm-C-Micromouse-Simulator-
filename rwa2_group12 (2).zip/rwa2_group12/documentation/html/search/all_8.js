var searchData=
[
  ['trace_5fback_5ffastest_52',['trace_back_fastest',['../classrwa2group12_1_1_algorithm.html#a6e006e856c442421983786c637cb5973',1,'rwa2group12::Algorithm']]],
  ['turn_5fleft_53',['turn_left',['../classrwa2group12_1_1_robot.html#ab7bb45954e05857353b4410cf374b319',1,'rwa2group12::Robot']]],
  ['turn_5fright_54',['turn_right',['../classrwa2group12_1_1_robot.html#a635fb9fcbc1cc127b3521a1fd6d83af6',1,'rwa2group12::Robot']]],
  ['turnleft_55',['turnLeft',['../class_simulator.html#ab103b5780fb3102441270df9c006e435',1,'Simulator']]],
  ['turnright_56',['turnRight',['../class_simulator.html#af3e20b66f7372a26639a2ecf6f881490',1,'Simulator']]]
];
